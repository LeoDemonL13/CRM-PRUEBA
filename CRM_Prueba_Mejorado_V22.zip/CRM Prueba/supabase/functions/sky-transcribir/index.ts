import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
}

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' }
})

const clean = (value: unknown, max = 1800) => String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max)

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Método no permitido.' }, 405)

  const url = Deno.env.get('SUPABASE_URL') ?? ''
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') ?? ''
  const openaiKey = Deno.env.get('OPENAI_API_KEY') ?? ''
  const model = Deno.env.get('SKY_TRANSCRIBE_MODEL') ?? 'gpt-4o-mini-transcribe'
  const authorization = req.headers.get('Authorization') ?? ''

  if (!url || !anonKey) return json({ error: 'La función no tiene configuradas las credenciales de Supabase.' }, 500)
  if (!authorization) return json({ error: 'Sesión no válida.' }, 401)

  try {
    const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authorization } } })
    const { data: userData, error: userError } = await userClient.auth.getUser()
    if (userError || !userData.user) return json({ error: 'Sesión no válida.' }, 401)

    const type = req.headers.get('content-type') ?? ''
    if (type.includes('application/json')) {
      const body = await req.json().catch(() => ({}))
      if (body?.ping === true) {
        return json({
          ok: true,
          configured: Boolean(openaiKey),
          message: openaiKey ? 'Servicio de voz avanzada disponible.' : 'Falta configurar OPENAI_API_KEY.'
        })
      }
    }

    if (!openaiKey) return json({ error: 'Sky Voz avanzada todavía no está configurada en el servidor.' }, 503)
    if (!type.includes('multipart/form-data')) return json({ error: 'Formato de audio no válido.' }, 400)

    const form = await req.formData()
    const file = form.get('audio')
    if (!(file instanceof File) || file.size <= 0) return json({ error: 'No se recibió audio.' }, 400)
    if (file.size > 25 * 1024 * 1024) return json({ error: 'El audio es demasiado grande.' }, 413)

    const profile = clean(form.get('profile'), 80)
    const context = clean(form.get('context'), 1800)
    const prompt = clean([
      'Transcribe español de México con precisión.',
      'Es una consulta hablada para el CRM de Skilled Proyectos Industriales.',
      profile ? `Perfil activo: ${profile}.` : '',
      context ? `Vocabulario y contexto útil: ${context}.` : '',
      'Conserva códigos, medidas, pulgadas, nombres de materiales, marcas, proveedores, proyectos y nombres propios tal como se entiendan.'
    ].filter(Boolean).join(' '), 2000)

    const body = new FormData()
    body.append('file', file, file.name || `sky-${Date.now()}.webm`)
    body.append('model', model)
    body.append('language', 'es')
    body.append('prompt', prompt)
    body.append('response_format', 'json')

    const started = Date.now()
    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${openaiKey}` },
      body
    })
    const payload = await response.json().catch(() => ({}))
    if (!response.ok) {
      const detail = clean(payload?.error?.message || payload?.message || `HTTP ${response.status}`, 500)
      return json({ error: `No se pudo transcribir el audio: ${detail}` }, 502)
    }

    const transcript = clean(payload?.text, 3000)
    if (!transcript) return json({ error: 'No se detectó una frase clara en el audio.' }, 422)
    return json({ ok: true, text: transcript, durationMs: Date.now() - started })
  } catch (error) {
    return json({ error: error instanceof Error ? error.message : 'No se pudo procesar la voz.' }, 500)
  }
})
